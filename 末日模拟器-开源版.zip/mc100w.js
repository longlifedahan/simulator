/* ============================================================
 * 末日模拟器 · 快速蒙特卡洛校准脚本
 * 复制 sim.js 核心引擎（不生成日志、跳过死决之地），跑各天赋 N 局
 * 用法：node mc100w.js <天赋1-10> [局数=1000000]
 * 输出 JSON：进化/99级/91级次数、战力分位(top1/5/10/25/50/75/90)的等级+战力、min/max战力
 * 说明：死决之地 cond 会触发 2000 局子模拟（极慢），本脚本按需跳过
 * ============================================================ */
var D = require('./data.js');
var W = require('./ability.js');
var E = require('./events.js');

/* ---------- 与 sim.js 一致的引擎（去日志） ---------- */
function rand(a, b) { return a + Math.random() * (b - a); }
function irand(a, b) { return Math.floor(rand(a, b + 1)); }
function round(x) { return Math.round(x); }

function breakChance(aptitude, lvl) {
  var seg;
  if (lvl >= 99) seg = 11; else if (lvl >= 96) seg = 10; else if (lvl >= 91) seg = 9;
  else if (lvl >= 81) seg = 8; else if (lvl >= 71) seg = 7; else if (lvl >= 61) seg = 6;
  else if (lvl >= 51) seg = 5; else if (lvl >= 41) seg = 4; else if (lvl >= 31) seg = 3;
  else if (lvl >= 21) seg = 2; else if (lvl >= 11) seg = 1; else seg = 0;
  return D.BREAK_CHANCE[aptitude - 1][seg] / 100;
}

function breakAgeCoef(g) {
  if (g.age <= 12) return 1.2;
  if (g.age <= 18) return 1.1;
  if (g.age > g.lifespan * 0.9) return 0.95;
  return 1.0;
}
/* 觉醒技能：按战力从 data.js SKILL_TIER 表取档 → 加战力 → 直升下一阶（10/20/..90 → 11/21/..91） */
function awakenSkill(g) {
  var tier = D.selectSkill(g.combat, g.lvl / 10);
  g.combat += irand(tier.addLo, tier.addHi);
  levelUp(g);
}
function attemptBreak(g) {
  if (g.lvl >= 99) return 0;
  if (g.lvl % 10 === 0) return 0;   /* 10/20/..90 大境界顶：由觉醒技能升级，不走正常突破 */
  var coef = breakAgeCoef(g);
  var th = (g.lvl % 10 === 9) ? 0.5 : 1;   /* 关口（9/19/..89）突破概率暂时性 /2 */
  var base = breakChance(g.aptitude, g.lvl) * coef * th;
  if (base <= 0.25 + 1e-9) return Math.random() < base ? 1 : 0;
  var gained = 0, step = 0;
  while (true) {
    var lvl = g.lvl + gained;
    if (lvl >= 99) break;
    if (lvl % 10 === 0) break;              /* 连破升到 10/20/..90 大境界顶停止，由觉醒技能升级 */
    var b = breakChance(g.aptitude, lvl) * coef * ((lvl % 10 === 9) ? 0.5 : 1);
    if (b <= 0.25 + 1e-9) break;
    var p = b * Math.pow(0.6, step);
    if (p <= 0.25 + 1e-9) break;
    if (Math.random() < p) { gained++; step++; } else break;
  }
  return gained;
}

function combatGain(aptitude, newLvl) {
  var c = D.COMBAT_COEF[aptitude];
  if (newLvl >= 90 && newLvl <= 98) return round(c * (newLvl * 0.6 + rand(-newLvl * 0.4, newLvl * 0.4) + 20));
  if (newLvl >= 99) return round(c * (newLvl * 1.2 + rand(-200, 200) + 200));
  return round(c * (newLvl * 0.6 + rand(-newLvl * 0.4, newLvl * 0.4) + 6));
}
function lifespanGain(newLvl) {
  if (newLvl === 99) return 100;
  if (newLvl >= 96 && newLvl <= 98) return 8;
  if (newLvl >= 91 && newLvl <= 95) return 5;
  if (newLvl >= 86 && newLvl <= 90) return 4;
  if (newLvl >= 76 && newLvl <= 85) return 3;
  if (newLvl >= 66 && newLvl <= 75) return 2;
  if (newLvl >= 55 && newLvl <= 65) return 1;
  return 0;
}
function evCombat(g, minPct, maxPct, floor) {
  var v = g.combat * rand(minPct, maxPct);
  if (v < (floor || 0)) v = floor || 0;
  return round(v);
}
function levelUp(g) {
  if (g.lvl >= 99) { g.combat += 10000; return; }
  var nl = g.lvl + 1;
  var cg = combatGain(g.aptitude, nl);
  var lg = lifespanGain(nl);
  g.lvl = nl; g.combat += cg; g.lifespan += lg;
}
function gainLevels(g, n) { for (var k = 0; k < n; k++) { levelUp(g); if (g.lvl % 10 === 0 && g.lvl < 99) awakenSkill(g); } }

function forcedChance(combat) {
  if (combat >= 750000) return 1.0;   /* 75w+ 必过 */
  if (combat < 100000) return 1e-4;
  if (combat < 400000) { var t = (combat - 100000) / 300000; return 1e-3 + t * (0.01 - 1e-3); }
  var t2 = (combat - 400000) / 350000; return 0.01 + t2 * (0.10 - 0.01);
}
function godCombat(combat, rate) {
  if (rate == null) rate = 1;
  return round((1000000 + combat) * rate);
}
function tryAscend(g) {
  var es = g.essence.length > 0 ? g.essence[0] : null;
  var rate = es ? es.rate : 1;
  if (!g.stat) g.stat = { sk: 0, dj: 0 };
  if (es) {
    g.stat.sk++;                          /* 有源质 → 尝试炼化源质 */
    if (g.combat >= es.needCombat) {
      g.ascendMode = 'refine'; g.ascended = true; g.lvl = 100;
      g.combat = godCombat(g.combat, rate); g.lifespan = 99999; return true;
    }
    /* 炼化失败：战力×源质倍率×达标比例×0.1 增幅基因（与 sim.js 一致） */
    g.combat += round(g.combat * es.rate * (g.combat / es.needCombat) * 0.1);
  }
  g.stat.dj++;                            /* 炼化失败转强行进化 / 无源质直接强行进化 */
  if (Math.random() < forcedChance(g.combat)) {
    g.ascendMode = 'forced'; g.ascended = true; g.lvl = 100;
    var dRate = D.FORCED_BONUS_MIN + Math.random() * (D.FORCED_BONUS_MAX - D.FORCED_BONUS_MIN);
    g.combat = godCombat(g.combat, dRate); g.lifespan = 99999; return true;
  }
  g.dead = true; g.ascendMode = 'fail'; return true;
}

function drawHighAbility(g) {
  var wsum = 0, i;
  for (i = 7; i <= 10; i++) wsum += W.INNATE_WEIGHTS[i];
  var r = Math.random() * wsum, acc = 0, ni = 7;
  for (i = 7; i <= 10; i++) { acc += W.INNATE_WEIGHTS[i]; if (r < acc) { ni = i; break; } }
  var grp = W.ABILITY_POOL[ni];
  var nw = grp[Math.floor(Math.random() * grp.length)];
  g.ability = nw; g.innate = ni; g.aptitude = ni;
  g.gotTwin = true;
  return { innate: ni, ability: nw };
}

/* 事件工具（死决之地被跳过，无需 testLv/testCombat） */
var U = {
  rand: rand, irand: irand, round: round,
  combatGain: combatGain, lifespanGain: lifespanGain,
  gainLevels: gainLevels, levelUp: levelUp, evCombat: evCombat, breakChance: breakChance,
  drawHighAbility: drawHighAbility,
  printlog: function () {},   /* 模拟脚本不打印事件日志 */
  DATA: D
};

function rollEvent(g) {
  var pool = [], i, mc = g.maxCount || (g.maxCount = {});
  for (i = 0; i < E.length; i++) {
    var evi = E[i];
    if (evi.id === 'deadzone') continue;   /* 跳过死决之地（cond 触发 2000 局子模拟，极慢） */
    var maxN = evi.maxCount != null ? evi.maxCount : 100;
    var left = mc[evi.id] != null ? mc[evi.id] : maxN;
    if (left <= 0) continue;
    var minA = evi.minAge != null ? evi.minAge : 0;
    var maxA = evi.maxAge != null ? evi.maxAge : 10000;
    if (g.age >= minA && g.age <= maxA) pool.push(evi);
  }
  if (!pool.length) return;
  var total = 0;
  for (i = 0; i < pool.length; i++) total += (pool[i].weight != null ? pool[i].weight : 1);
  var r = Math.random() * total, acc = 0, ev = pool[0];
  for (i = 0; i < pool.length; i++) { acc += (pool[i].weight != null ? pool[i].weight : 1); if (r < acc) { ev = pool[i]; break; } }
  var maxN2 = ev.maxCount != null ? ev.maxCount : 100;
  mc[ev.id] = (mc[ev.id] != null ? mc[ev.id] : maxN2) - 1;
  if (!ev.cond || ev.cond(g, U)) { if (ev.ok) ev.ok(g, U, null); }
  else { if (ev.fail) ev.fail(g, U, null); }
}

function rollYear(g) {
  g.year++; g.age++;
  if (Math.random() < D.ORIGIN_CHANCE) {
    g.ascendMode = 'origin'; g.ascended = true; g.lvl = 100;
    g.combat = godCombat(g.combat, D.ORIGIN_BONUS); g.lifespan = 99999; return;
  }
  if (Math.random() < D.XIJING_CHANCE) { g.aptitude = 10; g.lifespan += 50; g.gotMutation = true; }
  if (g.lvl >= 90 && g.essence.length < 1 && Math.random() < (g.lvl >= 99 ? D.ESSENCE_CHANCE * 1.25 : D.ESSENCE_CHANCE)) {
    var esR = D.ESSENCE[Math.floor(Math.random() * D.ESSENCE.length)];
    g.essence.push(xwR);
    g.combat += irand(5000, Math.round(xwR.needCombat * 0.05));   /* 获得源质战力 +rand(5000, needCombat×5%) */
    var ups = Math.min(irand(1, 3), 99 - g.lvl);   /* 同时升 1-3 级（不超过 99） */
    for (var upi = 0; upi < ups; upi++) levelUp(g);
  }
  if (g.lvl < 99) {
    var gained = attemptBreak(g);
    if (gained > 0) {
      for (var k = 0; k < gained; k++) { levelUp(g); if (g.lvl >= 99) break; }
    } else if (g.lvl % 10 !== 0) {
      /* 未突破且不在大境界顶：普通修炼战力微增 */
      g.combat += evCombat(g, 0.0005, 0.001, irand(1, 5));
    }
    /* 达到 10/20/..90（大境界顶）：觉醒技能直升下一阶 */
    if (g.lvl % 10 === 0 && g.lvl < 99) awakenSkill(g);
  }
  /* 99 级普通修炼连击（与 sim.js 一致）：100%→50%→25%… 每中一次 +99，失败即止 */
  if (g.lvl >= 99 && !g.ascended && (g.lifespan - g.age) > 10) {
    var limGain = 0, limStep = 0;
    while (true) {
      var lp = limStep === 0 ? 1 : (limStep === 1 ? 0.5 : 0.25);
      if (Math.random() < lp) { limGain += 99; limStep++; } else break;
      if (limStep >= 500) break;
    }
    g.combat += limGain;
  }
  if (g.lvl >= 99 && !g.ascended && (g.lifespan - g.age) <= 10) { if (tryAscend(g)) return; }
  if (g.age > g.lifespan) { g.dead = true; return; }
  if (!g.ascended && Math.random() < D.EVENT_CHANCE) rollEvent(g);
  if (g.age > g.lifespan) g.dead = true;
}

/* 初始战力：觉醒基础 + 从1级修炼到天赋级逐级突破累计（与 sim.js initialCombat 一致） */
function initialCombat(innate) {
  var c = irand(innate, innate * 10);
  for (var L = 2; L <= innate; L++) c += combatGain(innate, L);
  return c;
}

/* ---------- 主统计 ---------- */
function run(innate, n) {
  var asc = 0, forced = 0, refine = 0, origin = 0, attemptSk = 0, attemptDj = 0;
  var lim99 = 0, feng91 = 0, feng95 = 0, sumAge = 0, sumLvl = 0, sumC = 0;
  var maxC = -1, minC = 1e18, maxALvl = 0;
  var lvls = new Array(n), cs = new Array(n);
  for (var i = 0; i < n; i++) {
    var g = {
      innate: innate, aptitude: innate, ability: '', lvl: innate,
      combat: initialCombat(innate), lifespan: irand(D.LIFE_MIN + innate, D.LIFE_MAX + innate),
      age: 6, year: 0, essence: [], maxCount: {}, ascended: false, dead: false, ascendMode: null,
      stat: { sk: 0, dj: 0 }
    };
    var g0 = 0;
    while (!g.dead && !g.ascended && g0 < 20000) { g0++; rollYear(g); }
    lvls[i] = g.lvl; cs[i] = g.combat;
    if (g.ascended) {
      asc++;
      if (g.ascendMode === 'forced') forced++;
      else if (g.ascendMode === 'refine') refine++;
      else if (g.ascendMode === 'origin') origin++;
    }
    if (g.lvl >= 99) lim99++;
    if (g.lvl >= 91) feng91++;
    if (g.lvl >= 95) feng95++;
    attemptSk += g.stat.sk; attemptDj += g.stat.dj;
    sumAge += g.age; sumLvl += g.lvl; sumC += g.combat;
    if (g.combat > maxC) { maxC = g.combat; maxALvl = g.lvl; }
    if (g.combat < minC) minC = g.combat;
  }
  var order = new Array(n);
  for (var j = 0; j < n; j++) order[j] = j;
  order.sort(function (a, b) { return cs[b] - cs[a]; });
  var percs = [1, 5, 10, 25, 50, 75, 90];
  var rows = [];
  for (var p = 0; p < percs.length; p++) {
    var idx = order[Math.min(n - 1, Math.floor(percs[p] / 100 * n))];
    rows.push({ p: percs[p], lvl: lvls[idx], combat: cs[idx] });
  }
  return {
    innate: innate, n: n, asc: asc, forced: forced, refine: refine, origin: origin,
    attemptSk: attemptSk, attemptDj: attemptDj,
    lim99: lim99, feng91: feng91, feng95: feng95,
    avgAge: sumAge / n, avgLvl: sumLvl / n, avgC: sumC / n,
    maxC: maxC, maxALvl: maxALvl, minC: minC, rows: rows
  };
}

var innate = parseInt(process.argv[2], 10);
var N = parseInt(process.argv[3], 10) || 1000000;
if (innate >= 1 && innate <= 10) {
  var t0 = Date.now();
  var r = run(innate, N);
  console.log(JSON.stringify(r));
  process.stderr.write('天赋' + innate + ' ' + N + '局 完成 ' + ((Date.now() - t0) / 1000).toFixed(1) + 's 超生命体进化率 ' + (r.asc / N * 100).toFixed(2) + '%\n');
} else {
  console.log('用法: node mc100w.js <天赋1-10> [局数]');
}
